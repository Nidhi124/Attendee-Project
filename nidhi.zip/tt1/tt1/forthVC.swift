//
//  forthVC.swift
//  tt1
//
//  Created by Niketan on 30/08/20.
//  Copyright © 2020 Niketan. All rights reserved.
//

import UIKit

class forthVC: UIViewController {

    @IBOutlet var nameLab: UILabel!
    @IBOutlet var plab: UILabel!
    @IBOutlet var alab: UILabel!
    
    var data1 = [Any]()
    var p = [Int]()
    var a = [Int]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //check same data
        for i in storeData{
            let ii = i
            if ii[0] as? String == data1[0] as? String{
                if ii[1] as? Bool == true{
                    p.append(1)
                }else{
                     a.append(1)
                }
            }else{
                
            }
        }
        
        nameLab.text = data1[0] as? String
        plab.text = "Present = \(p.count)"
        alab.text = "Absent = \(a.count)"
    }
    

   @IBAction func btnback(_ sender: UIButton) {
       navigationController?.popViewController(animated: true)
   }

}
