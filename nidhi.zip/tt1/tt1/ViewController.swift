//
//  ViewController.swift
//  tt1
//
//  Created by Niketan on 29/08/20.
//  Copyright © 2020 Niketan. All rights reserved.
//

import UIKit


var storeData = [[Any]]()



class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func b1(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "seccond_ViewController") as? seccond_ViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    
    @IBAction func b2(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "third_ViewController") as? third_ViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
}

