//
//  seccond ViewController.swift
//  tt1
//
//  Created by Niketan on 29/08/20.
//  Copyright © 2020 Niketan. All rights reserved.
//

import UIKit

class seccond_ViewController: UIViewController {

    
    @IBOutlet var enterTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    
    @IBAction func btnBack(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnP(_ sender: UIButton) {
    
        // close keyboard
        view.endEditing(true)
        
        
        //validation
        if enterTF.text! == "" {
            let alert = UIAlertController(title: "Enter valid id", message: "", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "ok", style: .cancel, handler: nil))
            self.present(alert, animated: true)
        }else{
            storeData.append([enterTF.text!,true])
            enterTF.text! = ""
        }
    }
    
    @IBAction func btnA(_ sender: UIButton) {
        
        // close keyboard
        view.endEditing(true)
        
        
        //validation
        if enterTF.text! == "" {
            let alert = UIAlertController(title: "Enter valid id", message: "", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "ok", style: .cancel, handler: nil))
            self.present(alert, animated: true)

        }else{
            storeData.append([enterTF.text!,false])
            enterTF.text! = ""
        }
    }
    

}
