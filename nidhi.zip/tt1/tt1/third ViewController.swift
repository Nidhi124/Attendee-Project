//
//  third ViewController.swift
//  tt1
//
//  Created by Niketan on 29/08/20.
//  Copyright © 2020 Niketan. All rights reserved.
//

import UIKit

class third_ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{

    @IBOutlet var tableView: UITableView!
    
    //store data
    var data = [[Any]]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // add store data
        data = storeData
        tableView.reloadData()
        
    }
    
       //MARK: - TableView
       
       func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return data.count
       }
       
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TVCell
           
            let dict = data[indexPath.row]
            
            cell.nameLab.text = dict[0] as? String
        
        
            //check user present or absent
            let status = dict[1] as? Bool
            if status == true{
                cell.designView.backgroundColor = UIColor.white
                cell.statusLab.text = "Present"
                cell.changeSBtn.setTitle("Absent", for: .normal)
            }else{
                cell.designView.backgroundColor = UIColor.red
                cell.statusLab.text = "Absent"
                cell.changeSBtn.setTitle("Present", for: .normal)
            }
            
        
            // vlaue change btn
            cell.changeSBtn.tag = indexPath.row
            cell.changeSBtn.addTarget(self, action: #selector(self.favUnselect(_ :)), for: .touchUpInside)
        
            // goto next btn
            cell.btnNext.tag = indexPath.row
            cell.btnNext.addTarget(self, action: #selector(self.next(_ :)), for: .touchUpInside)
           
           return cell
       }
    
    
    @objc func favUnselect(_ sender : UIButton) {
        let tapIndex = sender.tag
        let dict = data[tapIndex]
        let status = dict[1] as? Bool
        
        if status == true{
            data[tapIndex][1] = false
        }else{
            data[tapIndex][1] = true
        }
        
        storeData.removeAll()
        storeData = data
        tableView.reloadData()
    }
    
    @objc func next(_ sender : UIButton) {
        let tapIndex = sender.tag
        let dict = data[tapIndex]
        
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "forthVC") as? forthVC
        vc?.data1 = dict
        self.navigationController?.pushViewController(vc!, animated: true)
        
    }
    
       
       func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
           print("You tapped cell number \(indexPath.item).")
           
       }
    
    
    

    @IBAction func btnback(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    

}
